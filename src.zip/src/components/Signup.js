import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Signup.css";
import bgImage from "../assets/bg.webp";
import { FaGoogle, FaFacebookF, FaTwitter } from "react-icons/fa";

export default function Signup() {
  const [isStaff, setIsStaff] = useState(false);

  // existing states
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const navigate = useNavigate();

  const handleSocialClick = (platform) =>
    alert(`${platform} login clicked`);

  // ✅ UPDATED: validation + EMAIL OTP
  const handleSendOtp = async () => {
    if (!name || !email || !password || !confirmPassword) {
      alert("All fields are required");
      return;
    }

    if (!/\S+@\S+\.\S+/.test(email)) {
      alert("Enter a valid email");
      return;
    }

    if (password.length < 6) {
      alert("Password must be at least 6 characters");
      return;
    }

    if (password !== confirmPassword) {
      alert("Passwords do not match");
      return;
    }

    try {
      const res = await fetch("http://localhost:5000/send-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });

      const data = await res.json();

      if (data.success) {
        localStorage.setItem("signupEmail", email);
        navigate("/otp");
      } else {
        alert("Failed to send OTP");
      }
    } catch (error) {
      alert("Server not running");
    }
  };

  return (
    <div
      className="page"
      style={{
        backgroundImage: `linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url(${bgImage})`,
      }}
    >
      <div className={`container ${isStaff ? "staff-active" : ""}`}>
        <div className="panel form-panel">
          {!isStaff ? (
            <>
              <h2>Admin Signup</h2>

              <input placeholder="Admin Name" onChange={(e) => setName(e.target.value)} />
              <input placeholder="Email" onChange={(e) => setEmail(e.target.value)} />
              <input type="password" placeholder="Password" onChange={(e) => setPassword(e.target.value)} />
              <input type="password" placeholder="Confirm Password" onChange={(e) => setConfirmPassword(e.target.value)} />

              <button className="submit" onClick={handleSendOtp}>
                Send OTP
              </button>

              <p className="login-text">
                Already have an account?{" "}
                <span onClick={() => navigate("/login")} style={{ cursor: "pointer" }}>
                  Login
                </span>
              </p>

              <div className="social-icons">
                <FaGoogle onClick={() => handleSocialClick("Google")} />
                <FaFacebookF onClick={() => handleSocialClick("Facebook")} />
                <FaTwitter onClick={() => handleSocialClick("Twitter")} />
              </div>
            </>
          ) : (
            <>
              <h2>Admin Access</h2>
              <p>Full system control</p>
              <button onClick={() => setIsStaff(false)}>Admin Signup</button>
            </>
          )}
        </div>

        {/* STAFF PANEL */}
        <div className="panel button-panel">
          {isStaff ? (
            <>
              <h2>Staff Signup</h2>

              <input placeholder="Staff Name" onChange={(e) => setName(e.target.value)} />
              <input placeholder="Email" onChange={(e) => setEmail(e.target.value)} />
              <input type="password" placeholder="Password" onChange={(e) => setPassword(e.target.value)} />
              <input type="password" placeholder="Confirm Password" onChange={(e) => setConfirmPassword(e.target.value)} />

              <button className="submit green" onClick={handleSendOtp}>
                Send OTP
              </button>

              <p className="login-text light">
                Already have an account?{" "}
                <span onClick={() => navigate("/login")} style={{ cursor: "pointer" }}>
                  Login
                </span>
              </p>

              <div className="social-icons light">
                <FaGoogle onClick={() => handleSocialClick("Google")} />
                <FaFacebookF onClick={() => handleSocialClick("Facebook")} />
                <FaTwitter onClick={() => handleSocialClick("Twitter")} />
              </div>
            </>
          ) : (
            <>
              <h2>Staff Access</h2>
              <p>Stock management only</p>
              <button onClick={() => setIsStaff(true)}>Staff Signup</button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
