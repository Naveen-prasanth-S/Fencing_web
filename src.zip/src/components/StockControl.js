import "./StockControl.css";

function StockControl() {
  return (
    <div className="stock">
      <h3>Stock Control</h3>
      <input placeholder="Product Name" />
      <input placeholder="Quantity" />
      <button>Add</button>
    </div>
  );
}

export default StockControl;
