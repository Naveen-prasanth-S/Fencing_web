import "./BillingCalculation.css";

function BillingCalculation() {
  return (
    <div className="billing">
      <h3>Billing & Calculation</h3>
      <p>Total Sales: ₹50,000</p>
      <p>Profit: ₹15,000</p>
    </div>
  );
}

export default BillingCalculation;
