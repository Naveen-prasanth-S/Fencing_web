import { useNavigate } from "react-router-dom";
import "./Login.css";
import bgImage from "../assets/lbg.jpg";

export default function Login() {
  const navigate = useNavigate();

  const handleLogin = () => {
    alert("Login clicked");
  };

  return (
    <div
      className="login-page"
      style={{
        backgroundImage: `linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url(${bgImage})`,
      }}
    >
      <div className="login-container">
        <h2>Login</h2>

        <input type="email" placeholder="Email" />
        <input type="password" placeholder="Password" />

        <button className="login-btn" onClick={handleLogin}>
          Login
        </button>

        <p className="signup-text">
          Don't have an account?{" "}
          <span
            onClick={() => navigate("/signup")}
            style={{ cursor: "pointer" }}
          >
            Signup
          </span>
        </p>
      </div>
    </div>
  );
}
