import { Routes, Route } from "react-router-dom";
import Signup from "./components/Signup";
import Login from "./components/Login";
import StockControl from "./components/StockControl";
import BillingCalculation from "./components/BillingCalculation";
import GPSTracker from "./components/GPSTracker";
import Otp from "./components/otp";

function App() {
  return (
    <Routes>

      {/* FIRST PAGE */}
      <Route path="/" element={<Signup />} />

      {/* AUTH */}
      <Route path="/login" element={<Login />} />
      <Route path="/otp" element={<Otp />} />

      {/* MODULES */}
      <Route path="/stock" element={<StockControl />} />
      <Route path="/billing" element={<BillingCalculation />} />
      <Route path="/gps" element={<GPSTracker />} />

    </Routes>
  );
}

export default App;
